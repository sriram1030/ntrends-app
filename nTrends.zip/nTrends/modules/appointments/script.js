// --- GLOBAL VARIABLES ---
let allAppointments = [];
let selectedCustomerData = null; 
let serviceOptionsHTML = ''; 
let employeeOptionsHTML = '';

$(document).ready(function() {
    // 1. Initial Load
    let today = $('#dateFilter').val();
    loadDashboardAndTable(today);
    
    // Load dropdowns immediately
    loadDropdownData(); 

    // 2. Handle Date Filter Change
    $('#dateFilter').on('change', function() {
        let selectedDate = $(this).val();
        loadDashboardAndTable(selectedDate);
    });

    // 3. Handle Form Submit (Modal Create/Update)
    $('#apptForm').submit(function(e) {
        e.preventDefault();
        
        let $btn = $('#submitBtn');
        let originalText = $btn.text();
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Processing...');

        $.ajax({
            url: 'api.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res) {
                if(res.status === 'success') {
                    $('#apptModal').modal('hide');
                    loadDashboardAndTable($('#dateFilter').val());
                    Swal.fire('Success', 'Operation completed!', 'success');
                } else {
                    Swal.fire('Error', 'Operation failed.', 'error');
                }
            },
            error: function() { Swal.fire('Error', 'Server connection failed.', 'error'); },
            complete: function() { $btn.prop('disabled', false).text(originalText); }
        });
    });

    // 4. Handle "View Billing" Click (Yellow Button)
    $(document).on('click', '.view-bill-btn', function() {
        let id = $(this).data('id'); 
        let apptData = allAppointments.find(a => a.id == id);
        if (apptData) viewBilling(apptData);
    });

    // 5. NEW: Handle "Edit" Click (Blue Button)
    $(document).on('click', '.edit-btn', function() {
        let id = $(this).data('id'); 
        let apptData = allAppointments.find(a => a.id == id);
        
        if (apptData) {
            editAppt(apptData); // Call the edit function safely
        } else {
            Swal.fire('Error', 'Could not load details.', 'error');
        }
    });

    // 6. Search Input listener
    $('#customerSearchInput').on('keyup', function() {
        let query = $(this).val();
        if (query.length < 2) {
            $('#suggestionsList').addClass('d-none');
            return;
        }
        $.post('api.php', { action: 'search_clients', query: query }, function(data) {
            let html = '';
            if (data.length > 0) {
                data.forEach(client => {
                    let clientDataStr = JSON.stringify(client).replace(/"/g, '&quot;');
                    html += `
                        <div class="suggestion-item list-group-item list-group-item-action" onclick="selectCustomer(${clientDataStr})">
                            <div class="fw-bold">${client.client_phone} - <span class="text-primary text-uppercase">${client.client_name}</span></div>
                            <small class="text-muted">${client.gender} | ${client.client_type}</small>
                        </div>`;
                });
            } else {
                html = '<div class="list-group-item text-muted">No previous customers found. Click "New".</div>';
            }
            $('#suggestionsList').html(html).removeClass('d-none');
        }, 'json');
    });

    // Hide suggestions
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#customerSearchInput, #suggestionsList').length) {
            $('#suggestionsList').addClass('d-none');
        }
    });

    // 7. "Add Appointment" from Search Card
    $('#btnContinueToBook').on('click', function() {
        if (!selectedCustomerData) return;
        
        // Fill Info
        $('#advCustName').text(selectedCustomerData.client_name);
        $('#advCustPhone').text(selectedCustomerData.client_phone);
        loadCustomerHistory(selectedCustomerData.client_phone);
        
        // Reset Table and Open View
        $('#serviceCartBody').html(''); 
        addNewServiceRow();
        openBillingView(); 
    });
});

// --- HELPER FUNCTIONS ---

function loadDashboardAndTable(date) {
    // Load Counts & Revenue
    $.post('api.php', { action: 'fetch_counts', date_filter: date }, function(data) {
        $('#countOpen').text(data.open_count);
        $('#countClosed').text(data.closed_count);
        
        // NEW: Update Revenue Text
        // Formats number to 2 decimal places (e.g., 550.00)
        let revenue = parseFloat(data.total_revenue) || 0;
        $('#countRevenue').text('₹' + revenue.toFixed(2));
        
    }, 'json');

    $.post('api.php', { action: 'fetch_by_date', date_filter: date }, function(data) {
        // STORE DATA GLOBALLY
        allAppointments = data;

        let rows = '';
        if(data.length === 0) {
             rows = '<tr><td colspan="8" class="text-center text-muted py-4">No appointments found for this date.</td></tr>';
        } else {
            data.forEach(function(appt) {
                let statusBadge = appt.status === 'Scheduled' ? '<span class="badge bg-primary">Scheduled</span>' : 
                                  (appt.status === 'Completed' ? '<span class="badge bg-success">Completed</span>' : '<span class="badge bg-danger">Cancelled</span>');
                
                let timeParts = appt.appointment_time.split(':');
                let dateObj = new Date(0, 0, 0, timeParts[0], timeParts[1]);
                let formattedTime = dateObj.toLocaleTimeString('en-US', { hour: '2-digit', minute:'2-digit', hour12: true });

                rows += `
                <tr>
                    <td class="fw-bold text-primary">#${appt.id}</td>
                    <td><i class="far fa-clock text-muted me-1"></i> ${formattedTime}</td>
                    <td>
                        <div class="fw-bold">${appt.client_name}</div>
                        <small class="text-muted">${appt.client_phone || ''}</small>
                    </td>
                    <td><small>${appt.gender} / ${appt.client_type}</small></td>
                    <td class="text-indigo fw-medium"><i class="fas fa-user-tie me-1"></i> ${appt.employee_name}</td>
                    <td>
                            <div>${appt.service_name}</div>
                            <div class="fw-bold text-success">₹${parseFloat(appt.price).toFixed(2)}</div>
                    </td>
                    <td>${statusBadge}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-warning text-dark me-1 view-bill-btn" data-id="${appt.id}" title="View Billing">
                            <i class="fas fa-file-invoice-dollar"></i>
                        </button>

                        <button type="button" class="btn btn-sm btn-info text-white me-1 edit-btn" data-id="${appt.id}" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>

                        <button class="btn btn-sm btn-danger" onclick="deleteAppt(${appt.id})" title="Cancel">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>`;
            });
        }
        $('#apptTableBody').html(rows);
    }, 'json');
}

function loadDropdownData() {
    $.post('api.php', { action: 'fetch_dropdowns' }, function(data) {
        employeeOptionsHTML = '<option value="">Select Staff</option>';
        data.employees.forEach(e => {
            employeeOptionsHTML += `<option value="${e.id}">${e.name}</option>`;
        });

        serviceOptionsHTML = '<option value="" data-price="0">Select Service</option>';
        data.services.forEach(s => {
            serviceOptionsHTML += `<option value="${s.id}" data-price="${s.price}">${s.service_name}</option>`;
        });

        // Update Fallback Modal
        $('#employeeSelect').html(employeeOptionsHTML);
        $('#serviceSelect').html(serviceOptionsHTML);
    }, 'json');
}

// --- VIEW & MODAL LOGIC ---

function openModalForNew() {
     resetSearch();
    $('#customerSearchSection').slideUp();
    $('#apptForm')[0].reset();
    $('#apptId').val('');
    $('#formAction').val('create');
    $('#modalTitle').html('<i class="fas fa-calendar-plus me-2"></i>Book New Appointment');
    $('#submitBtn').text('Confirm Booking').removeClass('btn-warning').addClass('btn-primary');
    $('#statusDiv').hide();
    $('#apptDate').val($('#dateFilter').val());
    $('#apptModal').modal('show');
}

// Fixed Edit Logic
function editAppt(appt) {
    // Populate form fields
    $('#apptId').val(appt.id);
    $('#apptDate').val(appt.appointment_date);
    $('#apptTime').val(appt.appointment_time);
    $('#clientName').val(appt.client_name);
    $('#clientPhone').val(appt.client_phone);
    $('#clientGender').val(appt.gender);
    $('#clientType').val(appt.client_type);
    $('#employeeSelect').val(appt.employee_id);
    $('#serviceSelect').val(appt.service_id);
    $('#apptStatus').val(appt.status);
    
    // Change Form State to 'Update'
    $('#formAction').val('update');
    $('#modalTitle').html('<i class="fas fa-edit me-2"></i>Edit Appointment #' + appt.id);
    $('#submitBtn').text('Update Booking').removeClass('btn-primary').addClass('btn-warning');
    $('#statusDiv').show(); // Show status dropdown
    
    // Show Modal
    $('#apptModal').modal('show');
}

function deleteAppt(id) {
    Swal.fire({
        title: 'Cancel Appointment?',
        text: "Are you sure you want to cancel booking #" + id + "?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, Cancel it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('api.php', { action: 'delete', id: id }, function(res) {
                if(res.status === 'success') {
                    loadDashboardAndTable($('#dateFilter').val());
                    Swal.fire('Cancelled!', 'Appointment has been cancelled.', 'success');
                } else {
                    Swal.fire('Error', 'Could not cancel.', 'error');
                }
            }, 'json');
        }
    });
}

// --- SEARCH LOGIC ---

function toggleSearchSection() {
    $('#customerSearchSection').slideToggle();
    $('#customerSearchInput').focus();
    resetSearch();
}

function resetSearch() {
    $('#customerSearchInput').val('');
    $('#suggestionsList').addClass('d-none').html('');
    $('#selectedCustomerCard').hide();
    $('#btnContinueToBook').prop('disabled', true);
    selectedCustomerData = null;
}

function selectCustomer(clientData) {
    selectedCustomerData = clientData;
    $('#suggestionsList').addClass('d-none');
    $('#customerSearchInput').val('');
    $('#cardCustName').text(clientData.client_name);
    $('#cardCustPhone').text(clientData.client_phone);
    $('#cardCustGender').text(clientData.gender);
    $('#cardCustType').text(clientData.client_type);
    $('#selectedCustomerCard').fadeIn();
    $('#btnContinueToBook').prop('disabled', false);
}

// --- ADVANCED BILLING LOGIC ---

function loadCustomerHistory(phone) {
    $('#histVisits').text('Loading...');
    $('#histSpent').text('...');
    
    $.post('api.php', { action: 'fetch_client_history', client_phone: phone }, function(data) {
        let stats = data.stats;
        let bill = data.last_bill;
        
        $('#histVisits').text(stats.visit_count > 0 ? stats.visit_count : 'New Client');
        $('#histFirst').text(stats.first_visit || '--');
        $('#histLast').text(stats.last_visit || '--');
        $('#histSpent').text('₹' + (parseFloat(stats.total_spent) || 0).toFixed(2));
        
        if(bill) {
            $('#lastStylist').text(bill.stylist);
            $('#lastService').text(bill.service_name);
        } else {
            $('#lastStylist').text('--');
            $('#lastService').text('--');
        }
    }, 'json');
}

function addNewServiceRow() {
    let rowId = Date.now();
    let row = `
        <tr id="row_${rowId}">
            <td><select class="form-select form-select-sm emp-select">${employeeOptionsHTML}</select></td>
            <td><select class="form-select form-select-sm svc-select" onchange="updateRowPrice(${rowId}, this)">${serviceOptionsHTML}</select></td>
            <td><input type="number" class="form-control form-control-sm price-input" value="0" onkeyup="calculateRowTotal(${rowId})"></td>
            <td><input type="number" class="form-control form-control-sm total-input fw-bold" value="0" readonly></td>
            <td class="text-center">
                <button class="btn btn-sm btn-outline-danger border-0" onclick="$('#row_${rowId}').remove(); calculateGrandTotal();"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;
    $('#serviceCartBody').append(row);
}
function updateRowPrice(rowId, selectEl) {
    let price = $(selectEl).find(':selected').data('price');
    let row = $('#row_' + rowId);
    let basePrice = parseFloat(price) || 0;
    
    row.find('.price-input').val(basePrice.toFixed(2));
    row.find('.total-input').val(basePrice.toFixed(2));
    
    calculateGrandTotal();
}

function calculateGrandTotal() {
    let grandTotal = 0;
    $('#serviceCartBody tr').each(function() {
        let total = parseFloat($(this).find('.total-input').val()) || 0;
        grandTotal += total;
    });
    $('#headerNet').text('₹' + grandTotal.toFixed(2));
}

function saveAdvancedBooking() {
    let services = [];
    $('#serviceCartBody tr').each(function() {
        let empId = $(this).find('.emp-select').val();
        let svcId = $(this).find('.svc-select').val();
        if(empId && svcId) {
            services.push({ employee_id: empId, service_id: svcId });
        }
    });

    if(services.length === 0) {
        Swal.fire('Error', 'Please add at least one service', 'warning');
        return;
    }

    $.post('api.php', {
        action: 'create_multi',
        client_name: $('#advCustName').text(),
        client_phone: $('#advCustPhone').text(),
        gender: selectedCustomerData.gender,
        client_type: selectedCustomerData.client_type,
        appointment_date: $('#advDate').val(),
        services: services
    }, function(res) {
        if(res.status === 'success') {
            closeBillingView(); 
            $('#customerSearchSection').slideUp();
            loadDashboardAndTable($('#dateFilter').val());
            Swal.fire('Success', 'Appointment Saved!', 'success');
        } else {
            Swal.fire('Error', 'Failed to save', 'error');
        }
    }, 'json');
}

// --- VIEW BILLING FUNCTION ---

function viewBilling(appt) {
    $('#advCustName').text(appt.client_name);
    $('#advCustPhone').text(appt.client_phone);
    $('#advDate').val(appt.appointment_date);

    selectedCustomerData = {
        client_name: appt.client_name,
        client_phone: appt.client_phone,
        gender: appt.gender,
        client_type: appt.client_type
    };
    
    loadCustomerHistory(appt.client_phone);
    populateBillingRow(appt);
    openBillingView();
}

function populateBillingRow(appt) {
    $('#serviceCartBody').html(''); 
    
    let rowId = Date.now();
    let price = parseFloat(appt.price);

    let row = `
        <tr id="row_${rowId}">
            <td>
                <select class="form-select form-select-sm emp-select">${employeeOptionsHTML}</select>
            </td>
            <td>
                <select class="form-select form-select-sm svc-select" onchange="updateRowPrice(${rowId}, this)">${serviceOptionsHTML}</select>
            </td>
            <td>
                <input type="number" class="form-control form-control-sm price-input" value="${price.toFixed(2)}" onkeyup="calculateRowTotal(${rowId})">
            </td>
            <td>
                <input type="number" class="form-control form-control-sm total-input fw-bold" value="${price.toFixed(2)}" readonly>
            </td>
            <td class="text-center">
                <button class="btn btn-sm btn-outline-danger border-0" onclick="$('#row_${rowId}').remove(); calculateGrandTotal();">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>`;
    
    $('#serviceCartBody').append(row);

    // Set the values for the dropdowns
    let $row = $('#row_' + rowId);
    $row.find('.emp-select').val(appt.employee_id);
    $row.find('.svc-select').val(appt.service_id);
    
    calculateGrandTotal();
}

// --- VIEW TOGGLING FUNCTIONS ---
function openBillingView() {
    $('#mainDashboardView').addClass('d-none');
    $('#billingView').removeClass('d-none');
}

function closeBillingView() {
    $('#billingView').addClass('d-none');
    $('#mainDashboardView').removeClass('d-none');
}
// --- NEW HELPER: Updates totals when user MANUALLY types a price ---
function calculateRowTotal(rowId) {
    let row = $('#row_' + rowId);
    let price = parseFloat(row.find('.price-input').val()) || 0;
    
    // Update the Total field in that row (Total = Price since no GST)
    row.find('.total-input').val(price.toFixed(2));
    
    // Update the Grand Total at the top
    calculateGrandTotal();
}